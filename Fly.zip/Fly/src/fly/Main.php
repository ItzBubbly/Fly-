<?php

declare(strict_types=1);

namespace fly;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\server\CommandEvent;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\CancelTaskException;
use pocketmine\scheduler\ClosureTask;
use function array_shift;

class Main extends PluginBase implements Listener{

	public function onEnable() : void{
    
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }
    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool
    {

        if ($sender->hasPermission("fly.cmd")){
          if ($sender instanceof Player){
              switch ($command->getName()){
                  case "fly":
                      switch ($args[0]){
                          case "on":
                           $sender->setAllowFlight(true);
                           $sender->sendTitle("§l§aVuelo Activado!");
                           break;

                          case "off":
                              $sender->setAllowFlight(false);
                              $sender->sendTitle("§l§cVuelo Desactivado!");
                              $sender->setFlying(false);
                              break;
                          default:
                            $sender->sendMessage("Error usa /fly on/off");
                      }
                      break;

              }
          }
                }


        return true;
    }
}
